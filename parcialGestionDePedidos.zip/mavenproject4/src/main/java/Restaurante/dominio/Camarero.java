/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Restaurante.dominio;


import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Paola
 */
public class Camarero {
    public String nombre;

    public Camarero() {
    }

   
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
}
    
